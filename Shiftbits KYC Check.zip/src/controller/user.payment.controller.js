const axios = require("axios");
const PGDB = require("../config/db");
const Utility = require("../utility/util");
const { v4: uuidv4 } = require('uuid');
const moment = require("moment");
const xml2js = require("xml2js").parseString;
const reqHeaderXML = { headers: { "Content-Type": "text/xml" } };
const reqHeader = {
  "Content-Type": "text/plain",
  "Content-Type": "application/x-www-form-urlencoded"
};

module.exports = {

  parseXmlResponse: async function (req) {
    try {
      let xmlResponse = req;
      let parsedJsObject = {};

      let options = { explicitArray: false, attrkey: 'att', charkey: "char" };
      // convert xml to js object
      xml2js(xmlResponse, options, function (err, result) {
        parsedJsObject = result["SOAP-ENV:Envelope"]["SOAP-ENV:Body"]["ns0:Reversal"]["ns0:Details"];
      });
      return parsedJsObject;
    } catch (e) {
      return { error: e };
    }
  },

  makePayment: async (paymentData, paymentType) => {
    const messageId = uuidv4();
    const currentDate = moment().format("YYYY-MM-DD");

    const reqObj = `<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:pay="http://www.kotak.com/schemas/CMS_Generic/Payment_Request.xsd">
                                <soap:Header/>
                                <soap:Body>
                                   <pay:Payment>
                                      <pay:RequestHeader>
                                         <pay:MessageId>${messageId}</pay:MessageId>
                                         <pay:MsgSource>${AppConfig.MSG_SOURCE}</pay:MsgSource>
                                         <pay:ClientCode>${AppConfig.CLIENT_CODE}</pay:ClientCode>
                                         <pay:BatchRefNmbr>12345678</pay:BatchRefNmbr>
                                      </pay:RequestHeader>
                                      <pay:InstrumentList>
                                         <pay:instrument>
                                            <pay:InstRefNo>05072021_001</pay:InstRefNo>
                                            <pay:MyProdCode>WPAY</pay:MyProdCode>
                                            <pay:TxnAmnt>${paymentData["Amount"]}</pay:TxnAmnt>
                                            <pay:AccountNo>09582650000173</pay:AccountNo>
                                            <pay:DrRefNmbr>123</pay:DrRefNmbr>
                                            <pay:DrDesc>Testing</pay:DrDesc>
                                            <pay:PaymentDt>${currentDate}</pay:PaymentDt>
                                            <pay:RecBrCd>${paymentData["Remit_Ifsc"]}</pay:RecBrCd>
                                            <pay:BeneAcctNo>${paymentData["Remit_Ac_Nmbr"]}</pay:BeneAcctNo>
                                            <pay:BeneName>${paymentData["Remit_Name"]}</pay:BeneName>
                                            <pay:BeneEmail>${AppConfig.TX_EMAIL}</pay:BeneEmail>
                                            <pay:EnrichmentSet>
                                               <!--1 or more repetitions:-->
                                               <pay:Enrichment>Something</pay:Enrichment>
                                            </pay:EnrichmentSet>
                                         </pay:instrument>
                                      </pay:InstrumentList>
                                   </pay:Payment>
                                </soap:Body>
                             </soap:Envelope>`;

    let header = {
      "Content-Type": "application/xml",
      "SOAPAction": "/BusinessServices/StarterProcesses/CMS_Generic_Service.serviceagent/Payment"
    };

    let responseObj = await axios.post(AppConfig.MAKE_PAYMENT, reqObj, {
      headers: header
    });

    let paymentObj = {
      messageId: messageId,
      userId: userBankDetails["userId"],
      modeOfPayment: getPayment["Pay_Mode"],
      amount: getPayment["Amount"],
      utrNumber: getPayment["Utr_No"],
    }

    if (paymentType == "refund") {
      paymentObj["paymentStatus"] = "refund";
    }

    else if (paymentType == "debit") {
      paymentObj["paymentStatus"] = "debit";
    }

    const paymentResponse = await PGDB.pg.models.payment.create(paymentObj);

    const getUser = await PGDB.pg.models.user.findByPk(userBankDetails["userId"]);

    if (getUser["email"]) {
      const emailSub = `Payment Response`;

      Utility.sendEmail(getUser["email"], emailSub, emailBody);
    }
  },

  checkPaymentStatus: async (messageId, paymentDate, paymentType) => {
    try {
      const reqObj = `<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:rev="http://www.kotak.com/schemas/CMS_Generic/Reversal_Request.xsd">\
        <soap:Header/>\
        <soap:Body>\
        <rev:Reversal>\
            <rev:Header>\
                <rev:Req_Id>${messageId}</rev:Req_Id>\
                <rev:Msg_Src>${AppConfig.MSG_SOURCE}</rev:Msg_Src>\
                <rev:Client_Code>${AppConfig.CLIENT_CODE}</rev:Client_Code>\
                <rev:Date_Post>${paymentDate}</rev:Date_Post>\
            </rev:Header>\
            <rev:Details>\
                <!--Zero or more repetitions:-->\
                <rev:Msg_Id>${messageId}</rev:Msg_Id>\
            </rev:Details>\
        </rev:Reversal>\
        </soap:Body>\
        </soap:Envelope>`;

      let header = {
        "Content-Type": "application/xml",
        "SOAPAction": "/BusinessServices/StarterProcesses/CMS_Generic_Service.serviceagent/Reversal"
      };

      let responseObj = await axios.post(AppConfig.PAYMENT_STATUS, reqObj, {
        headers: header
      });

      const parsedRes = await module.exports.parseXmlResponse(responseObj.data);

      const refundStatus = parsedRes["ns0:Rev_Detail"];

    } catch (e) {
      console.log("error", e)
    }

  },

  paymentCheck: async () => {
    try {
      let responseObj = await axios.post(AppConfig.TOKEN_GENERATE, AppConfig.CMS_TOKEN, reqHeader);
      let accessToken = responseObj["data"]["access_token"];
      if (responseObj.status == 200) {
        let header = {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${accessToken}`
        };
        let body = {
          "Header": {
            "SrcAppCd": "ECOLLECTION",
            "RequestID": "BINSWAP007"
          },
          "CMSGenericInboundReq": {
            "MerchantName": "BINSWAP",
            "MerchantSecret": ""
          }
        };
        let paymentRes = await axios.post(AppConfig.PAYMENT_CHECK, body, header);

        const countPayment = paymentRes["data"]["CMSGenericInboundResponse"]["CMSGenericInboundRes"]["CollectionDetails"]["CollectionDetail"];

        for (let getPayment of countPayment) {
          const userBankDetails = await PGDB.pg.models.bank.findOne({
            where: {
              virtualAccountNumber: getPayment["E_Coll_Acc_No"],
              accountNumber: getPayment["Remit_Ac_Nmbr"]
            },
            raw: true
          })

          let paymentObj = {};
          let emailBody;
          if (userBankDetails) {
            paymentObj = {
              userId: userBankDetails["userId"],
              messageId: null,
              modeOfPayment: getPayment["Pay_Mode"],
              amount: getPayment["Amount"],
              paymentStatus: "credit",
              utrNumber: getPayment["Utr_No"],
            }

            const paymentResponse = await PGDB.pg.models.payment.create(paymentObj);
            emailBody = `<strong>n ${paymentObj["amount"]} Has Been Successfully Credited to ShiftBits Account</strong>`;
          }
          else {
            makePayment(getPayment, "refund");
          }
        }
      }
    } catch (e) {
      console.log("Error::", e)
    }
  },

  //WithDraw Payment
  withdrawPayment: async (req, res, next) => {
    try {
      const reqObj = req.body;

      const findPayment = await PGDB.pg.models.payments.findOne({
        where: {
          cyptoTransactionId: reqObj["TransactionId"],
        },
        raw: true,
      })

      const getBankAccount = await PGDB.pg.models.bank.findByPk(findPayment["userId"]);
      const getUser = await PGDB.pg.models.users.findByPk(findPayment["userId"]);

      const getPayment = {
        Amount: reqObj["ValueToPayout"],
        Remit_Ifsc: getBankAccount["ifscCode"],
        Remit_Ac_Nmbr: getBankAccount["accountNumber"],
        Remit_Name: getUser["firstName"] + getUser["lastName"]
      }

      makePayment(getPayment, "debit");
    } catch (err) {
      console.log(err);
      err.resMsg = i18n.__("SOMETHING_WENT_WRONG");
      err.resCode = i18n.__("responseStatus.ERROR");
      return next(err);
    }
  },
}