const i18n = require("i18n");
const axios = require("axios");
const Utility = require("../utility/util");
const httpStatus = require("../exception/httpstatus.json");
var onfido_token = "api_sandbox.JD0hX9kSw1N.L7v3TKK3pdFsIJ_YnSR4W6eQp_snNLL6";
const { Onfido, Region } = require("@onfido/api");
const onfido = new Onfido({
  apiToken: "api_sandbox.JD0hX9kSw1N.L7v3TKK3pdFsIJ_YnSR4W6eQp_snNLL6",
  region: Region.EU
});
const PGDB = require("../config/db");

// req.user
// {
//   userId: 11,
//   phone: '9938225493',
//   email: null,
//   userRole: 'customer',
//   iat: 1630125224
// }

module.exports = {

  createApplicant: async (req, res, next) => {
    try {
      const User = await PGDB.pg.models.user.findByPk(req.user["userId"], { raw: true });

      if (!User) {
        const err = {};
        err.resMsg = i18n.__("NO_USER_FOUND");
        err.resCode = i18n.__("responseStatus.FAILURE");
        return next(err);
      }

      delete User["otp"];
      delete User["userId"];
      delete User["emailOtp"];
      delete User["verifyEmail"];
      delete User["verifyPhone"];
      delete User["verifyOtp"];

      const applicant = await onfido.applicant.create({
        firstName: User.firstName,
        lastName: User.lastName
      });

      // return Utility.response(res,
      //   {
      //     applicant_id: applicant.id
      //   },
      //   i18n.__("ONFIDO_SDK_CREATED"),
      //   httpStatus.OK,
      //   i18n.__("responseStatus.SUCCESS"))

      module.exports.generateOnfidoToken(applicant.id, res, next);

    } catch (err) {
      console.log(err);
      err.resMsg = i18n.__("SOMETHING_WENT_WRONG");
      err.resCode = i18n.__("responseStatus.ERROR");
      return next(err);
    }
  },

  generateOnfidoToken: async (applicant_id, res, next) => {
    try {
      axios
        .post(
          AppConfig.ONFIDO + "/v3.2/sdk_token",
          {
            "applicant_id": applicant_id,
            "referrer": "http://*.localhost:3000/*"
          },
          {
            headers: {
              'Authorization': "Token token=" + onfido_token
            }
          }
        )
        .then(function (response) {
          return Utility.response(res,
            {
              applicant_id: applicant_id,
              token: response.data.token
            },
            i18n.__("ONFIDO_SDK_CREATED"),
            httpStatus.OK,
            i18n.__("responseStatus.SUCCESS"))
        })
        .catch(function (error) {
          console.log(error);
          error.resMsg = i18n.__("SOMETHING_WENT_WRONG");
          error.resCode = i18n.__("responseStatus.ERROR");
          return next(error);
        })
    } catch (err) {
      console.log(err);
      err.resMsg = i18n.__("SOMETHING_WENT_WRONG");
      err.resCode = i18n.__("responseStatus.ERROR");
      return next(err);
    }
  },

  createCheck: async (req, res, next) => {
    try {
      const check = await onfido.check.create({
        applicantId: req.body.applicant_id,
        reportNames: ["document"]
      });

      await PGDB.pg.models.kyc.update({
        // identityPhoto: reqObj["identityPhoto"],
        identityPhoto: "",
        // identityType: reqObj["identityType"],
        identityType: "",
        applicantId: req.body.applicant_id,
        reportId: check["reportIds"],
        resultUri: check["resultsUri"]
      }, {
        where: {
          userId: req.user.userId
        },
        plain: true,
        nest: true
      });

      return Utility.response(res,
        {},
        i18n.__("KYC_CHECK_INITIATED"),
        httpStatus.OK,
        i18n.__("responseStatus.SUCCESS")
      )
    } catch (err) {
      console.log(err);
      err.resMsg = i18n.__("SOMETHING_WENT_WRONG");
      err.resCode = i18n.__("responseStatus.ERROR");
      return next(err);
    }
  },
}