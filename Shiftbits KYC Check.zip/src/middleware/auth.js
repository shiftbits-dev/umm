const jwt = require("jsonwebtoken");
const i18n = require("i18n");
const httpStatus = require("../exception/httpstatus.json");
const Utility = require("../utility/util");

module.exports = {

  async auth(req, res, next) {
    try {
      const token = req.headers.authorization.split(" ")[1];
      const decoded = jwt.verify(token, AppConfig.JWT_SECRET);
      req.user = decoded;
      next();
    }
    catch (err) {
      console.log(err);
      return Utility.response(res,
        {},
        i18n.__("INVALID_TOKEN"),
        httpStatus.UNAUTHORIZED,
        i18n.__("responseStatus.FAILURE")
      )
    }
  },

  async isCustomer(req, res, next) {
    try {
      const userPayload = req.user;

      if (!(userPayload["userRole"] === 'customer')) {
        return Utility.response(res, {},
          i18n.__("UNAUTHORIZED_USER"),
          httpStatus.UNAUTHORIZED,
          i18n.__("responseStatus.FAILURE"))
      }
      next();
    } catch (err) {
      console.log(err);
      err.resMsg = i18n.__("SOMETHING_WENT_WRONG");
      err.resCode = i18n.__("responseStatus.ERROR");
      return next(err);
    }
  },

  async isSuperUser(req, res, next) {
    try {
      const userPayload = req.user;

      if (!(userPayload["userRole"] === 'superadmin')) {
        return Utility.response(res, {},
          i18n.__("UNAUTHORIZED_USER"),
          httpStatus.UNAUTHORIZED,
          i18n.__("responseStatus.FAILURE"))
      }
      next();
    } catch (err) {
      console.log(err);
      err.resMsg = i18n.__("SOMETHING_WENT_WRONG");
      err.resCode = i18n.__("responseStatus.ERROR");
      return next(err);
    }
  },

  async isSupportAdmin(req, res, next) {
    try {
      const userPayload = req.user;

      if (!(userPayload["userRole"] === 'supportadmin')) {
        return Utility.response(res, {},
          i18n.__("UNAUTHORIZED_USER"),
          httpStatus.UNAUTHORIZED,
          i18n.__("responseStatus.FAILURE"))
      }
      next();
    } catch (err) {
      console.log(err);
      err.resMsg = i18n.__("SOMETHING_WENT_WRONG");
      err.resCode = i18n.__("responseStatus.ERROR");
      return next(err);
    }
  }
}