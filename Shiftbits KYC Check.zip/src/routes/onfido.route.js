const express = require("express");
const router = express.Router();
const onfidoController = require("../controller/onfido.controller");
const auth = require("../middleware/auth");
const { upload } = require("../utility/fileUpload");

router.post("/createApplicant", auth.auth, onfidoController.createApplicant);

router.post("/generateOnfidoToken", auth.auth, onfidoController.generateOnfidoToken);

router.post("/createCheck", auth.auth, onfidoController.createCheck);

module.exports = router;