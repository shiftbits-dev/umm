const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth");
const PaymentController = require("../controller/user.payment.controller");

router.post("/withdrawPayment", auth.auth, PaymentController.withdrawPayment);

module.exports = router;