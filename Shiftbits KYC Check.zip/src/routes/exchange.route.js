const express = require("express");
const router = express.Router();
const ExchangeController = require("../controller/exchange.controller");
const auth = require("../middleware/auth");

router.post("/getBuyCryptoCurrencyLimits", auth.auth, ExchangeController.getBuyCryptoCurrencyLimits);

router.post("/getBuyPrice", auth.auth,ExchangeController.getBuyPrice);

router.post("/startBuyTransaction", auth.auth, ExchangeController.startBuyTransaction);

router.post("/getSellCryptoCurrencyLimits", auth.auth, ExchangeController.getSellCryptoCurrencyLimits);

router.post("/getSellPrice", auth.auth,ExchangeController.getSellPrice);

router.post("/startSellTransaction", auth.auth, ExchangeController.startSellTransaction);

router.post("/viewBuyTransactions", auth.auth, ExchangeController.viewBuyTransaction);

router.post("/viewSellTransaction", auth.auth, ExchangeController.viewSellTransaction);

module.exports = router;