const express = require("express");
const router = express.Router();
const BankController = require("../controller/user.bank.controller");
const auth = require("../middleware/auth");

router.post("/addBank", auth.auth, BankController.addBankAccount);

router.get("/getBankAccount", auth.auth,BankController.getUserDetails);

router.post("/updateBank", auth.auth, BankController.updateBankAccount);

router.post("/getFiatTransactions", auth.auth, BankController.getFiatTransactions);

router.get("/getAmount", auth.auth, BankController.getAmount);

module.exports = router;