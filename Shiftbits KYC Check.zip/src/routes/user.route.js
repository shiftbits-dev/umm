const express = require("express");
const router = express.Router();
const UserController = require("../controller/user.controller");
const zendDeskController = require("../controller/user.zendesk");
const auth = require("../middleware/auth");
const { upload } = require("../utility/fileUpload");

router.post("/register", UserController.register);

router.post("/login", UserController.login);

router.put("/", auth.auth, UserController.updateUser);

router.post("/verifyPhone", auth.auth, UserController.verifyPhone)

router.get("/", auth.auth, UserController.getUser);

router.post("/verifyOtp", auth.auth, UserController.verifyOtp);

router.post("/updatePhone", auth.auth, UserController.updatePhone);

router.get("/emailVerification", auth.auth, UserController.emailVerification);

router.post("/verifyEmail", auth.auth, UserController.verifyEmail);

router.post("/profilePicture", auth.auth, upload.single('image'), UserController.profilePicture);

router.post("/getUserInfo", auth.auth, UserController.getUserById);

router.get("/getUserRequest", auth.auth, zendDeskController.getUserList);

router.post("/userRaiseRequest", auth.auth, zendDeskController.raiseRequest);

router.post("/logout", auth.auth, UserController.logout);

module.exports = router;