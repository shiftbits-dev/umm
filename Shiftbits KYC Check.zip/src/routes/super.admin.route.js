const express = require("express");
const router = express.Router();
const adminController = require("../controller/super.admin.controller");
const auth = require("../middleware/auth");

router.get("/allUser", auth.auth, auth.isSuperUser, adminController.getAllUser);

router.post("/updateKyc", auth.auth, auth.isSuperUser, adminController.getAllUserKyc);

router.get("/getAllRaiseTicket", auth.auth, auth.isSuperUser, adminController.getAllRaiseTicket);

module.exports = router;