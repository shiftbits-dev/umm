const express = require("express");
const router = express.Router();
const KycController = require("../controller/user.kyc.controller");
const auth = require("../middleware/auth");
const { upload } = require("../utility/fileUpload");

router.post("/uploadFile", auth.auth, upload.single('image'), KycController.fileupload);

router.post("/update", auth.auth, KycController.updateKyc);

router.post("/kycCheck", KycController.kycCheck);

router.get("/getKycStatus", auth.auth, KycController.getKycStatus);

module.exports = router;