const express = require('express');
const router = express.Router();
const axios = require('axios');

/** GET /health-check - Check service health */
router.get('/', (req, res) =>
    res.send('Welcome to Shiftbits APIs.')
);

router.get('/send_ip', (req, res) => {
    axios.get('https://nextstacks-backend-01.herokuapp.com/check_ip')
        .then(function (response) {
            res.send('IP check initiated');
        })
        .catch(function (error) {
            console.log(error);
        })
        // .then(function () {
        //     res.send('IP check initiated');
        // });
});


module.exports = router;