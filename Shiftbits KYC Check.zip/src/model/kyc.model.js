const DataTypes = require("sequelize");

module.exports = (sequelize) => {
    sequelize.define('kyc', {
        userId: {
            allowNull: false,
            primaryKey: true,
            type: DataTypes.BIGINT
        },
        verifyIdentity: {
            type: DataTypes.BOOLEAN,
            defaultValue: false
        },
        applicantId: {
            type: DataTypes.STRING
        },
        checkId: {
            type: DataTypes.STRING
        },
        resultUri: {
            type: DataTypes.STRING
        },
        kycStatus: {
            type: DataTypes.TEXT
        },
        identityPhoto: {
            type: DataTypes.TEXT
        },
        createdAt: {
            type: DataTypes.DATE,
            defaultValue: sequelize.NOW
        },
        updatedAt: {
            type: DataTypes.DATE,
            defaultValue: sequelize.NOW
        }
    }, {
        freezeTableName: true,
    })
}