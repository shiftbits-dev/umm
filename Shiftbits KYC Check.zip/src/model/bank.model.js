const DataTypes = require("sequelize");

module.exports = (sequelize) => {
    sequelize.define('bank', {
        userId: {
            allowNull: false,
            primarykey: true,
            type: DataTypes.BIGINT,
        },
        accountNumber: {
            unique: true,
            type: DataTypes.BIGINT
        },
        ifscCode: {
            type: DataTypes.TEXT
        },
        virtualAccountNumber: {
            unique: true,
            type: DataTypes.TEXT
        },
        createdAt: {
            type: DataTypes.DATE,
            defaultValue: sequelize.NOW
        },
        updatedAt: {
            type: DataTypes.DATE,
            defaultValue: sequelize.NOW
        }
    }, {
        freezeTableName: true,
    })
}