# shiftbits_postgres
# ShiftBits To create a user-management module that will perform authentication, authorization, communication, payments, and other functions for ShiftBits core, and through that, the ShiftBits Mobile App (being developed in React Native).  Some of the aspects to focus on are extensibility, security, and scalability (including performance)
